package com.literaturegame.literaturegame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteratureGameApplicationTests {

	@Test
	void contextLoads() {
		
		
		
	}

}
