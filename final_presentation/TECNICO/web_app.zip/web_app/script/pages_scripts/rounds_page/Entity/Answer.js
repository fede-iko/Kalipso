class Answer {

    constructor(id, answerText) {
        this.id = id;
        this.answerText = answerText;
    }

}