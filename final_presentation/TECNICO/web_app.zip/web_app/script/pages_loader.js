function loadUserNameForm() {
    $(".main-container").load("./src/user_name_form.html");
}

function loadMenuPage() {
    $(".main-container").load("./src/menu_page.html");
}

function loadRoundsPage() {
    $(".main-container").load("./src/rounds_page.html");
}

function loadEndPage() {
    $(".main-container").load("./src/end_page.html");
}

function loadResultsPage() {
    $(".main-container").load("./src/results_page.html");
}